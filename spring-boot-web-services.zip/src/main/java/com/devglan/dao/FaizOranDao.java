package com.devglan.dao;

import com.devglan.model.FaizOran;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface FaizOranDao extends CrudRepository<FaizOran, Long> {
 //   Urunler findById(long id);


}
