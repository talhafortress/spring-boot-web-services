package com.devglan.dao;

import com.devglan.model.Urunler;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface UrunlerDao extends CrudRepository<Urunler, Long> {
 //   Urunler findById(long id);


}

