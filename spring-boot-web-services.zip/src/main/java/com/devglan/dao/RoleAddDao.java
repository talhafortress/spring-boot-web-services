package com.devglan.dao;

import javax.persistence.*;
import com.devglan.model.User_roles;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import javax.persistence.EntityManager;
import org.springframework.data.jpa.repository.Query;

@Repository
public interface RoleAddDao extends CrudRepository<User_roles, Long> {
User_roles findById(long user_id);

    /*
    @Modifying
    @Query(value = "insert into user_roles(user_id, role_id) values (:userid, :roleid) ", nativeQuery = true)
    @Transactional
    void addRole(@Param("userid") int id, @Param("roleid") int roleid);

*/
}