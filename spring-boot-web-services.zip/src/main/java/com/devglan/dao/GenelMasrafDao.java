package com.devglan.dao;

import com.devglan.model.GenelMasraf;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface GenelMasrafDao extends CrudRepository<GenelMasraf, Long> {
 //   Urunler findById(long id);


}
