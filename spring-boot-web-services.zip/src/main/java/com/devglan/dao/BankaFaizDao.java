package com.devglan.dao;

import com.devglan.model.Bankafaiz;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface BankaFaizDao extends CrudRepository<Bankafaiz, Long> {
 //   Urunler findById(long id);


}
