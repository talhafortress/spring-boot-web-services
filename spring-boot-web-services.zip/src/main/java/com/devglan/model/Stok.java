package com.devglan.model;

import com.fasterxml.jackson.annotation.JsonIgnore;

import javax.persistence.*;
import java.util.Set;

@Entity
public class Stok {
    @Id
    @GeneratedValue(strategy= GenerationType.IDENTITY)
    private long id;
    private long depo_id;
    private long urun_id;
    private long urun_adet;

    public void setId(long id) {this.id =id;}
    public long getId() {return id;}
    public void setdepo_Id(long depo_id) {this.depo_id = depo_id;}
    public long getdepo_Id() { return depo_id;}

    public void seturun_Id(long urun_id) {this.urun_id = urun_id;}
    public long geturun_Id() { return urun_id;}

    public void seturun_Adet(long urun_adet) {this.urun_adet = urun_adet;}
    public long geturun_Adet() { return urun_adet;}


}