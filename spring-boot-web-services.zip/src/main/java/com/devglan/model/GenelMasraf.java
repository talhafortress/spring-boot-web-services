package com.devglan.model;

import com.fasterxml.jackson.annotation.JsonIgnore;

import javax.persistence.*;
import java.util.Set;
@Entity
public class GenelMasraf {

    @Id
    @GeneratedValue(strategy= GenerationType.IDENTITY)
    private long id;
    private long urun_id;
    private float kdv_orani;
    private float topmasraf;

    public void setId(long id) {this.id = id;}
    public long getId() {return id;}

    public void seturun_Id(long urun_id) {this.urun_id = urun_id;}
    public long geturun_Id() {return urun_id;}

    public void setkdv_Orani(float kdv_orani) {this.kdv_orani = kdv_orani;}
    public float getkdv_Orani() {return kdv_orani;}

    public void settopMasraf(float topmasraf) {this.topmasraf = topmasraf;}
    public float gettopMasraf() {return topmasraf;}

}