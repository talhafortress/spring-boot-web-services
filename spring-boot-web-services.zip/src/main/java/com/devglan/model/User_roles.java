package com.devglan.model;

import com.fasterxml.jackson.annotation.JsonIgnore;

import javax.persistence.*;
import java.util.Set;


@Entity
public class User_roles {
    @Id
    int user_id;
    int role_id;

    public int getuserId() {
        return user_id;
    }

    public void setuserId(int user_id) {
        this.user_id = user_id;
    }

    public int getroleId() {
        return role_id;
    }
    public void setroleId(int role_id) {
        this.role_id = role_id;
    }
}
