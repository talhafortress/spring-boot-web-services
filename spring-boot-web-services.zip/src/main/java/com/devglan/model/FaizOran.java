package com.devglan.model;

import com.fasterxml.jackson.annotation.JsonIgnore;

import javax.persistence.*;
import java.util.Set;
@Entity
public class FaizOran {

    @Id
    @GeneratedValue(strategy= GenerationType.IDENTITY)
    private long id;
    private float genelfaiz_orani;
    private boolean isactive;

    public void setId(long id) {this.id = id;}
    public long getId() {return id;}

    public void setgenelfaiz_Orani(float genelfaiz_orani) {this.genelfaiz_orani = genelfaiz_orani;}
    public float getgenelfaiz_Orani() {return genelfaiz_orani;}

    public void setisActive(boolean isactive) {this.isactive = isactive;}
    public boolean getisActive() {return isactive;}

}