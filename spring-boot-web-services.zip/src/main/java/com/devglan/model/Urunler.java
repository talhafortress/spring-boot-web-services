package com.devglan.model;

import com.fasterxml.jackson.annotation.JsonIgnore;

import javax.persistence.*;
import java.util.Set;

@Entity
public class Urunler {
    @Id
    private long id;
    private long fiyat;

    public long geturunId() {return id;}
    public void seturunId(long id) {this.id = id;}
    public long getFiyat() { return fiyat;}
    public void setFiyat(long fiyat) {this.fiyat = fiyat;}


}