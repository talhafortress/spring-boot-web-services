package com.devglan.model;

public class FaizOranDto {
    public float genelfaiz_orani;
    public boolean isactive;

    public void setgenelfaiz_Orani(float genelfaiz_orani) {this.genelfaiz_orani = genelfaiz_orani;}
    public float getgenelfaiz_Orani() {return genelfaiz_orani;}

    public void setisActive(boolean isactive) {this.isactive = isactive;}
    public boolean getisActive() {return isactive;}

}