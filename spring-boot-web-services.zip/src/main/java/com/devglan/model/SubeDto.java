package com.devglan.model;

public class SubeDto {

    private long id;
    private long admin_id;
    public long getId() {return id;}
    public void setId(long id) {this.id = id;}
    public long getadminId() {return admin_id;}
    public void setadminId(long admin_id) {this.admin_id = admin_id;}
}