package com.devglan.model;

import com.fasterxml.jackson.annotation.JsonIgnore;

import javax.persistence.*;
import java.util.Set;
@Entity
public class Bankafaiz {

    @Id
    @GeneratedValue(strategy= GenerationType.IDENTITY)
    private long id;
    private float faizoran;

    public void setId(long id) {this.id = id;}
    public long getId() {return id;}

    public void setfaizOran(float faizoran) {this.faizoran = faizoran;}
    public float getfaizOran() {return faizoran;}


}
