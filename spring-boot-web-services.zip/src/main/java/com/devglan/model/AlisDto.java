package com.devglan.model;

public class AlisDto {

    public long urun_id;
    public long sube_id;
    public long urun_maliyeti;

    public void seturun_Id(long urun_id) {this.urun_id = urun_id;}
    public long geturun_Id() { return urun_id;}

    public void setsube_Id(long sube_id) {this.sube_id = sube_id;}
    public long getsube_Id() { return sube_id;}

    public void seturun_Maliyeti(long urun_maliyeti) {this.urun_maliyeti = urun_maliyeti;}
    public long geturun_Maliyeti() { return urun_maliyeti;}

}