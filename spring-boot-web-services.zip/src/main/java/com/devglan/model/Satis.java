package com.devglan.model;

import com.fasterxml.jackson.annotation.JsonIgnore;

import javax.persistence.*;
import java.util.Set;

@Entity
public class Satis {
    @Id
    @GeneratedValue(strategy= GenerationType.IDENTITY)
    private long id;
    private long urun_id;
    private long sube_id;
    private long urun_maliyeti;
    private long satis_kari;

    public void setId(long id) {this.id =id;}
    public long getId() {return id;}

    public void seturun_Id(long urun_id) {this.urun_id = urun_id;}
    public long geturun_Id() { return urun_id;}

    public void setsube_Id(long sube_id) {this.sube_id = sube_id;}
    public long getsube_Id() { return sube_id;}

    public void seturun_Maliyeti(long urun_maliyeti) {this.urun_maliyeti = urun_maliyeti;}
    public long geturun_Maliyeti() { return urun_maliyeti;}

    public void setsatis_Kari(long satis_kari) {this.satis_kari =satis_kari;}
    public long getsatis_Kari() {return satis_kari;}
}