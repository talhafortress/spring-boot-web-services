package com.devglan.model;

public class DepoDto {

    public long urun_id;
    public long urun_adet;
    public long sube_id;

    public void seturun_Id(long urun_id) {this.urun_id = urun_id;}
    public long geturun_Id() {return urun_id;}

    public void seturun_Adet(long urun_adet) {this.urun_adet = urun_adet;}
    public long geturun_Adet() {return urun_adet;}

    public void setsube_Id(long sube_id) {this.sube_id = sube_id;}
    public long getsube_Id() {return sube_id;}

}