package com.devglan.model;



public class RoleAddDto {

    private int user_id;
    private int role_id;

    public int getuserId() {
        return user_id;
    }

    public void setuserId(int user_id) {
        this.user_id = user_id;
    }

    public int getroleId() {
        return role_id;
    }
    public void setroleId(int role_id) {
        this.role_id = role_id;
    }
}