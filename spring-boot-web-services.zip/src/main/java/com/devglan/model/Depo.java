package com.devglan.model;

import com.fasterxml.jackson.annotation.JsonIgnore;

import javax.persistence.*;
import java.util.Set;
@Entity
public class Depo {

    @Id
    @GeneratedValue(strategy= GenerationType.IDENTITY)
    private long id;
    private long urun_id;
    private long urun_adet;
    private long sube_id;

    public void setId(long id) {this.id = id;}
    public long getId() {return id;}

    public void seturun_Id(long urun_id) {this.urun_id = urun_id;}
    public long geturun_Id() {return urun_id;}

    public void seturun_Adet(long urun_adet) {this.urun_adet = urun_adet;}
    public long geturun_Adet() {return urun_adet;}

    public void setsube_Id(long sube_id) {this.sube_id = sube_id;}
    public long getsube_Id() {return sube_id;}
}