package com.devglan.model;

public class BankaFaizDto{
    public float faizoran;

    public void setfaizOran(float faizoran) {this.faizoran = faizoran;}
    public float getfaizOran() {return faizoran;}
}