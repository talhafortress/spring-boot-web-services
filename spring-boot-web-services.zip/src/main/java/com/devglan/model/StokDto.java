package com.devglan.model;

public class StokDto {

    public long depo_id;
    public long urun_id;
    public long urun_adet;

    public void setdepo_Id(long depo_id) {this.depo_id = depo_id;}
    public long getdepo_Id() { return depo_id;}

    public void seturun_Id(long urun_id) {this.urun_id = urun_id;}
    public long geturun_Id() { return urun_id;}

    public void seturun_Adet(long urun_adet) {this.urun_adet = urun_adet;}
    public long geturun_Adet() { return urun_adet;}

}