package com.devglan.service;

import com.devglan.model.User;
import com.devglan.model.UserDto;
import com.devglan.model.User_roles;
import com.devglan.model.RoleAddDto;

import com.devglan.model.UrunlerDto;
import com.devglan.model.Urunler;

import com.devglan.model.Sube;
import com.devglan.model.SubeDto;

import com.devglan.model.Alis;
import com.devglan.model.AlisDto;

import com.devglan.model.Bankafaiz;
import com.devglan.model.BankaFaizDto;

import com.devglan.model.Depo;
import com.devglan.model.DepoDto;

import com.devglan.model.FaizOran;
import com.devglan.model.FaizOranDto;

import com.devglan.model.GenelMasraf;
import com.devglan.model.GenelMasrafDto;

import com.devglan.model.Satis;
import com.devglan.model.SatisDto;

import com.devglan.model.Stok;
import com.devglan.model.StokDto;



import java.util.List;

public interface UserService {

    User save(UserDto user);
    void update(UserDto user, Long id);
    List<User> findAll();
    void delete(long id);
    User findOne(String username);
    User findById(Long id);
    void saverole(RoleAddDto role);
    void addproduct(UrunlerDto urun);
    User_roles findByRoleId(long user_id);

    boolean eklesube(SubeDto sube);

    boolean savealis(AlisDto alis);

    boolean savebankfaiz(BankaFaizDto bankafaiz);

    boolean savedepo(DepoDto depo);
    FaizOran findFaizId(long id);
    boolean savefaizoran (FaizOranDto faizor);
    boolean savegenelmasraf(GenelMasrafDto genelmasraf);
    boolean savesatis(SatisDto satis);
    boolean savestok (StokDto stok);

}
