package com.devglan.service.impl;

import com.devglan.dao.UserDao;

import com.devglan.dao.RoleAddDao;
import com.devglan.model.User_roles;
import com.devglan.model.RoleAddDto;

import com.devglan.model.User;
import com.devglan.model.UserDto;

import com.devglan.service.UserService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import com.devglan.model.UrunlerDto;
import com.devglan.model.Urunler;
import com.devglan.dao.UrunlerDao;

import com.devglan.model.Sube;
import com.devglan.model.SubeDto;
import com.devglan.dao.SubeDao;

import com.devglan.model.Alis;
import com.devglan.model.AlisDto;
import com.devglan.dao.AlisDao;

import com.devglan.model.Bankafaiz;
import com.devglan.model.BankaFaizDto;
import com.devglan.dao.BankaFaizDao;

import com.devglan.model.Depo;
import com.devglan.model.DepoDto;
import com.devglan.dao.DepoDao;

import com.devglan.model.FaizOran;
import com.devglan.model.FaizOranDto;
import com.devglan.dao.FaizOranDao;

import com.devglan.model.GenelMasraf;
import com.devglan.model.GenelMasrafDto;
import com.devglan.dao.GenelMasrafDao;

import com.devglan.model.Satis;
import com.devglan.model.SatisDto;
import com.devglan.dao.SatisDao;

import com.devglan.model.Stok;
import com.devglan.model.StokDto;
import com.devglan.dao.StokDao;

import java.util.*;


@Service(value = "userService")
public class UserServiceImpl implements UserDetailsService, UserService {
	@Autowired
	private UserDao userDao;

	@Autowired
	private RoleAddDao roleDao;

	@Autowired
	private UrunlerDao urunDao;

	@Autowired
	private SubeDao subeDao;

	@Autowired
	private AlisDao alisDao;

	@Autowired
	private BankaFaizDao bankafaizDao;

	@Autowired
	private DepoDao depoDao;

	@Autowired
	private FaizOranDao faizoranDao;

	@Autowired
	private GenelMasrafDao genelmasrafDao;

	@Autowired
	private SatisDao satisDao;

	@Autowired
	private StokDao stokDao;



	@Autowired
	private BCryptPasswordEncoder bcryptEncoder;

	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		User user = userDao.findByUsername(username);
		if(user == null){
			throw new UsernameNotFoundException("Invalid username or password.");
		}
		return new org.springframework.security.core.userdetails.User(user.getUsername(), user.getPassword(), getAuthority(user));
	}

	private Set<SimpleGrantedAuthority> getAuthority(User user) {
        Set<SimpleGrantedAuthority> authorities = new HashSet<>();
		user.getRoles().forEach(role -> {
			//authorities.add(new SimpleGrantedAuthority(role.getName()));
            authorities.add(new SimpleGrantedAuthority("ROLE_" + role.getName()));
		});
		return authorities;
		//return Arrays.asList(new SimpleGrantedAuthority("ROLE_ADMIN"));
	}

	public List<User> findAll() {
		List<User> list = new ArrayList<>();
		userDao.findAll().iterator().forEachRemaining(list::add);
		return list;
	}

	//id'si verilen kullanıcıyı silme
	@Override
	public void delete(long id) {
		userDao.deleteById(id);
	}

	//username ile kullanıcı bulma
	@Override
	public User findOne(String username) {
		return userDao.findByUsername(username);
	}

	// kullanıcıyı id'sinden bulma
	@Override
	public User findById(Long id) {
		return userDao.findById(id).get();
	}

	//yeni kullanıcı ekleme fonksiyonu
	@Override
    public User save(UserDto user) {
	    User newUser = new User();
	    newUser.setUsername(user.getUsername());
	    newUser.setPassword(bcryptEncoder.encode(user.getPassword()));
		newUser.setAge(user.getAge());
		newUser.setSalary(user.getSalary());
        return userDao.save(newUser);
	}

	// kullanıcı güncelleme fonksiyonu
	@Override
    public void update(UserDto user, Long id) {
		User newUser = findById(id);
	    newUser.setUsername(user.getUsername());
	    newUser.setPassword(bcryptEncoder.encode(user.getPassword()));
		newUser.setAge(user.getAge());
		newUser.setSalary(user.getSalary());
		userDao.save(newUser);
	}

	//yetki ekleme fonksiyonu
	@Override
	public void saverole(RoleAddDto role) {
		User_roles a = new User_roles();
		a.setuserId(role.getuserId());
		a.setroleId(role.getroleId());
		roleDao.save(a);
	}

	// ürün ekleme fonksiyonu
	@Override
	public void addproduct(UrunlerDto urun) {
	Urunler a = new Urunler();
	a.seturunId(urun.geturunId());
	a.setFiyat(urun.getFiyat());
	urunDao.save(a);
	}


	@Override
	public User_roles findByRoleId(long user_id) {
		return roleDao.findById(user_id);
	}
	//sube ekleme fonksiyonu 
	// bu fonksiyonda eklenecek kişinin id'si aynı zamanda müşteri olmayacak!!!
	@Override
	public boolean eklesube(SubeDto sube) {
		Sube a = new Sube();
		a.setId(sube.getId());
		a.setadminId(sube.getadminId());
		/*int adminid = sube.getadminId();
		User_roles role = findByRoleId(adminid); role id'si 5 olmayanlara şube eklenemez
		int roletype = role.getroleId();
		*/
		if(findById(a.getadminId()) != null) {
			subeDao.save(a);
			return true;
		}
		else {return false;}
	}

	@Override
	public boolean savealis(AlisDto alis) {
		Alis a = new Alis();
		a.seturun_Id(alis.geturun_Id());
		a.setsube_Id(alis.getsube_Id());
		a.seturun_Maliyeti(alis.geturun_Maliyeti());
		alisDao.save(a);
		return true;
	}

	@Override
	public boolean savebankfaiz(BankaFaizDto bankafaiz) {
		Bankafaiz a = new Bankafaiz();
		a.setfaizOran(bankafaiz.getfaizOran());
		bankafaizDao.save(a);
		return true;
	}
	@Override
	public boolean savedepo(DepoDto depo) {
		Depo a = new Depo();
		a.seturun_Id(depo.geturun_Id());
		a.seturun_Adet(depo.geturun_Adet());
		a.setsube_Id(depo.getsube_Id());
		depoDao.save(a);
		return true;
	}
	@Override
	public FaizOran findFaizId(long id) {
		return faizoranDao.findById(id).get();
	} // bunu faizoran için kullanıcaksın...
	@Override
	public boolean savefaizoran(FaizOranDto faizor) {
		FaizOran a = new FaizOran();
		a.setgenelfaiz_Orani(faizor.getgenelfaiz_Orani());
		a.setisActive(true);
		faizoranDao.save(a);
		long id = a.getId();
		id--;
        for(long i=id; i>0; i--) {
			if(findFaizId(i) != null) {
			FaizOran eskioran = findFaizId(i);
			eskioran.setisActive(false);
			faizoranDao.save(eskioran);
			}
			else if (findFaizId(i) == null) {
				break;
			}
		}
		return true;
	}

	@Override
	public boolean savegenelmasraf(GenelMasrafDto genelmasraf) {
		GenelMasraf a = new GenelMasraf();
		a.seturun_Id(genelmasraf.geturun_Id());
		a.setkdv_Orani(genelmasraf.getkdv_Orani());
		a.settopMasraf(genelmasraf.gettopMasraf());
		genelmasrafDao.save(a);

		return true;
	}
	@Override // tekrar gözden geçir
	public boolean savesatis(SatisDto satis){
		Satis a = new Satis();
		a.seturun_Id(satis.geturun_Id());
		a.setsube_Id(satis.getsube_Id());
		a.seturun_Maliyeti(satis.geturun_Maliyeti());
		a.setsatis_Kari(satis.getsatis_Kari());
		satisDao.save(a);
		return true;
	}

	@Override
	public boolean savestok (StokDto stok) {
		Stok a = new Stok();
		a.setdepo_Id(stok.getdepo_Id());
		a.seturun_Id(stok.geturun_Id());
		a.seturun_Adet(stok.geturun_Adet());
		stokDao.save(a);

		return true;
	}

}
