package com.devglan.controller;

import com.devglan.model.User;
import com.devglan.model.UserDto;

import com.devglan.model.User_roles;
import com.devglan.model.RoleAddDto;

import com.devglan.model.Urunler;
import com.devglan.model.UrunlerDto;

import com.devglan.model.Sube;
import com.devglan.model.SubeDto;

import com.devglan.model.Alis;
import com.devglan.model.AlisDto;

import com.devglan.model.Bankafaiz;
import com.devglan.model.BankaFaizDto;

import com.devglan.model.Depo;
import com.devglan.model.DepoDto;

import com.devglan.model.FaizOran;
import com.devglan.model.FaizOranDto;

import com.devglan.model.GenelMasraf;
import com.devglan.model.GenelMasrafDto;

import com.devglan.model.Satis;
import com.devglan.model.SatisDto;

import com.devglan.model.Stok;
import com.devglan.model.StokDto;

import com.devglan.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.annotation.Secured;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@CrossOrigin(origins = "*", maxAge = 3600)
@RestController
public class UserController {

    @Autowired
    private UserService userService;

    //@Secured({"ROLE_MASTER", "ROLE_USER", "ROLE_PERSON", "ROLE_CUSTOMER"})
    // MASTER - MASTER ADMIN
    // ADMIN - ŞUBE MÜDÜRÜ
    // PERSON - PERSONEL
    // CUSTOMER - MÜŞTERİLER
    @PreAuthorize("hasRole('MASTER')")
    @RequestMapping(value="/users", method = RequestMethod.GET)
    public List<User> listUser(){
        return userService.findAll();
    }

    //@Secured("ROLE_USER")
    @PreAuthorize("hasRole('MASTER')")
    ////@PreAuthorize("hasAnyRole('USER', 'ADMIN')")
    @RequestMapping(value = "/users/{id}", method = RequestMethod.GET)
    public User getOne(@PathVariable(value = "id") Long id){
        return userService.findById(id);
    }

    @PreAuthorize("hasRole('MASTER')")
    @RequestMapping(value="/adduser", method = RequestMethod.POST)
    public User saveUser(@RequestBody UserDto user){
        return userService.save(user);
    }
   @PreAuthorize("hasRole('MASTER')")
    ////@PreAuthorize("hasAnyRole('USER', 'ADMIN')")
    @RequestMapping(value = "/deleteuser/{id}", method = RequestMethod.GET)
    public boolean deleteUser(@PathVariable(value = "id") Long id){
        userService.delete(id);
        return true;
    }

    @PreAuthorize("hasRole('MASTER')")
    @RequestMapping(value="/updateuser/{id}", method = RequestMethod.POST)
    public boolean updateUser(@PathVariable (value = "id") Long id,@RequestBody UserDto user){
        userService.update(user, id);
        return true;
    }
    @PreAuthorize("hasRole('MASTER')")
    @RequestMapping(value="/updaterole/{user_id}/{role_id}", method = RequestMethod.POST)
    public boolean saveUser(@PathVariable (value ="user_id") int user_id, @PathVariable (value ="role_id") int role_id ){
        RoleAddDto a = new RoleAddDto();
        a.setuserId(user_id);
        a.setroleId(role_id);
        userService.saverole(a);
        return true;
    }
    @PreAuthorize("hasAnyRole('ADMIN', 'MASTER')")
    @RequestMapping(value ="/urunekle/{id}/{fiyat}", method = RequestMethod.POST)
    public boolean addProduct(@PathVariable (value = "id") long id, @PathVariable (value = "fiyat") long fiyat){
        UrunlerDto a = new UrunlerDto();
        a.seturunId(id);
        a.setFiyat(fiyat);
        userService.addproduct(a);
        return true;
    }
    @PreAuthorize("hasRole('MASTER')")
    @RequestMapping(value ="/subekle/{id}/{admin}", method = RequestMethod.POST)
    public boolean addSube(@PathVariable (value = "id") long id, @PathVariable (value = "admin") long admin){
        SubeDto a = new SubeDto();
        a.setId(id);
        a.setadminId(admin);
        return userService.eklesube(a);
    }

    @PreAuthorize("hasAnyRole('MASTER', 'ADMIN')")
    @RequestMapping(value="/addalis", method = RequestMethod.POST)
    public boolean saveAlis(@RequestBody AlisDto alis){
        userService.savealis(alis);
        return true;
    }
     @PreAuthorize("hasRole('MASTER')")
    @RequestMapping(value="/addbankafaiz/{faiz}", method = RequestMethod.POST)
    public boolean saveBankfaiz(@PathVariable (value="faiz") float faiz){
        BankaFaizDto a = new BankaFaizDto();
        a.setfaizOran(faiz);
        userService.savebankfaiz(a);
        return true;
    }

    @PreAuthorize("hasRole('MASTER')")
    @RequestMapping(value="/adddepo", method = RequestMethod.POST)
    public boolean saveDepo(@RequestBody DepoDto depo){
        userService.savedepo(depo);
        return true;
    }

    @PreAuthorize("hasRole('MASTER')")
    @RequestMapping(value="/addfaizoran", method = RequestMethod.POST)
    public boolean saveFaizOran(@RequestBody FaizOranDto faiz){
        userService.savefaizoran(faiz);
        return true;
    }

    @PreAuthorize("hasRole('MASTER')")
    @RequestMapping(value="/addgenelmasraf", method = RequestMethod.POST)
    public boolean saveGenelMasraf(@RequestBody GenelMasrafDto masraf){
        userService.savegenelmasraf(masraf);
        return true;
    }
      @PreAuthorize("hasRole('MASTER')")
    @RequestMapping(value="/addsatis", method = RequestMethod.POST)
    public boolean saveSatis(@RequestBody SatisDto satis){
        userService.savesatis(satis);
        return true;
    }

    @PreAuthorize("hasRole('MASTER')")
    @RequestMapping(value="/addstok", method = RequestMethod.POST)
    public boolean saveStok(@RequestBody StokDto stok){
        userService.savestok(stok);
        return true;
    }

}
